package com.highradius.model;

public class Invoice {
	 private int id;

	    public Invoice(int id) {
	        this.id = id;
	    }

	    public int getId() {
	        return id;
	    }

	    public void setId(int id) {
	        this.id = id;
	    }
public static void main(String args[])
{
	Invoice obj=new Invoice(12);
	System.out.println(obj.id);
}
}