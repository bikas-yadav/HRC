package com.highradius.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServlet;

import com.highradius.implementation.InvoiceDao;
import com.highradius.implementation.InvoiceDaoImpl;
import com.highradius.model.invoice;

public class DataLoadingServlet extends HttpServlet{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 935908040710534884L;
	private InvoiceDao invoiceDao;
	
	public DataLoadingServlet() {
		// TODO Auto-generated constructor stub
		super();
		init();
	}
	

	   public void init() { 
		 invoiceDao = new InvoiceDaoImpl();
	}
	   
	   
	     //Method getInvoice with return list of invoices to get all Invoices data using InvoiceDao getInvoice method

	    public List<invoice> getInvoice() throws IOException {
	        return invoiceDao.getInvoice();
	    }
	    
	    
	    public static void main(String[] args) throws IOException {
			DataLoadingServlet dl = new DataLoadingServlet();
			
			List<invoice> inv =dl.getInvoice();
			
			for(invoice in : inv) {
				System.out.println(in+"\n"); 	
			}
			
			
		}
}
