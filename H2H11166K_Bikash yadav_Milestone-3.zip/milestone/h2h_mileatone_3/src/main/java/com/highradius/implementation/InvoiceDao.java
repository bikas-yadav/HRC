package com.highradius.implementation;

import java.util.List;

import com.highradius.model.invoice;

public interface InvoiceDao {
	
	//Method getInvoice return list of invoices
	public List<invoice> getInvoice();
	
	
	//Method insertInvoice takes  invoice object
	public void  insertInvoice(invoice inv);
	
	
	//Method updateInvoice takes id, and invoice object to update
	public void updateInvoice(int id,invoice inv);
	
	
	//Method deleteInvoice takes id to be deleted for invoice
	public void deleteInvoice(int id);
	
}
