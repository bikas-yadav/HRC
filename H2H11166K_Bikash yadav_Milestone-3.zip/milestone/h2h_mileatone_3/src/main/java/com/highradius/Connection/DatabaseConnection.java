package com.highradius.Connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.highradius.model.invoice;


public class DatabaseConnection {
	private static DatabaseConnection instance = new DatabaseConnection();
	public  final String URL = "jdbc:mysql://localhost:3306/oap_h2h";
	 	public  final String USER = "root";
	 	public  final String PASSWORD = "root";
	 	public  final String SQL_DRIVER = "com.mysql.cj.jdbc.Driver";
	 	public Connection connection = null;
	 	
	
	
 	// constructor
 	public DatabaseConnection(){
	 		try
	 		{
	 			//Step 2: Load MySQL Java driver
	 			Class.forName(SQL_DRIVER);
	 		} 
	 		catch(ClassNotFoundException e)
	 		{
	 			e.printStackTrace();
	 		}
 		
 	}
 	
 	
 	 private Connection createConnection() {
 		
 		
 		try
 		 {
 			//Step 3: Establish Java MySQL connection
 			connection = DriverManager.getConnection(URL, USER, PASSWORD);
 			
 		} 
 		catch (SQLException e) {
 			System.out.println("ERROR: Unable to Connect to Database.");
 		}
 		return connection;
 	}
 	 
 	public static Connection getConnection() {
		return instance.createConnection();
	}
 	 
 	
 	public void disconnect() {
 		if(connection != null) {
 			connection = null;
 		}
 	}
 	 
 	 
 	 //List of Invoices
     List<invoice> invoices = new ArrayList<>();
     
     
     // Method getInvoices to return list of invoices
     public List<invoice> getInvoices() {
    	 Connection c = DatabaseConnection.getConnection();
	        String query = "SELECT * FROM h2h_oap";

	        try {
	            PreparedStatement p = c.prepareStatement(query);
	            ResultSet rs = p.executeQuery();
	            
	            int j = 30; 
	            while (rs.next() && j>0) { 
	        		 invoices.add(new invoice(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getString(4),
	        				 rs.getString(5),rs.getFloat(6),rs.getString(7),rs.getInt(8),
	        				 rs.getString(9),rs.getString(10),rs.getString(11),rs.getInt(12),
	        				 rs.getFloat(13),rs.getString(14),rs.getString(15),rs.getString(16),
	        				 rs.getInt(17),rs.getFloat(18),rs.getLong(19))); 
	        		 j--; 
	            }
	        } 
	        catch (SQLException e) {
	            e.printStackTrace();
	        }
	        finally {
	        	disconnect();
			}
		return invoices;
     }
     
     
     //Method addInvoice to Add Invoice to the list
     @SuppressWarnings("null")
	public void AddInvoice(invoice inv) {
    	 Connection connection = DatabaseConnection.getConnection();
    	 String queryString = "INSERT into h2h_oap(CUSTOMER_ORDER_ID"
    	 		+ " ,SALES_ORG"
    	 		+ " ,DISTRIBUTION_CHANNEL"
    	 		+ " ,DIVISION"
    	 		+ ",RELEASED_CREDIT_VALUE"
    	 		+ ", PURCHASE_ORDER_TYPE"
    	 		+ ", COMPANY_CODE"
    	 		+ ", ORDER_CREATION_DATE"
    	 		+ ", ORDER_CREATION_TIME"
    	 		+ ", CREDIT_CONTROL_AREA"
    	 		+ ", SOLD_TO_PARTY"
    	 		+ ", ORDER_AMOUNT"
    	 		+ ", REQUESTED_DELIVERY_DATE"
    	 		+ ", ORDER_CURRENCY"
    	 		+ ", CREDIT_STATUS"
    	 		+ ", CUSTOMER_NUMBER"
    	 		+ ", AMOUNT_IN_USD"
    	 		+ ", UNIQUE_CUST_ID)"
    	 		+"values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    	 
    	 try {
			PreparedStatement ps = connection.prepareStatement(queryString);
			ps.setInt(1, inv.getCUSTOMER_ORDER_ID());
			ps.setInt(2, inv.getSALES_ORG());
			ps.setString(3, inv.getDISTRIBUION_CHANNEL());
			ps.setString(4, inv.getDIVISION());
			ps.setDouble(5, inv.getRELEASED_CREDIT_VALUE());
			ps.setString(6,inv.getPURCHASE_ORDER_TYPE());
			ps.setInt(7, inv.getCOMPANY_CODE());
			ps.setString(8, inv.getORDER_CREATION_DATE());
			ps.setString(9,inv.getORDER_CREATION_TIME());
			ps.setString(10, inv.getCREDIT_CONTROL_AREA());
			ps.setInt(11, inv.getSOLD_TO_PARTY());
			ps.setDouble(12, inv.getORDER_AMOUNT());
			ps.setString(13,inv.getREQUESTED_DELIVERY_DATE());
			ps.setString(14, inv.getORDER_CURRENCY());
			ps.setString(15, inv.getCREDIT_STATUS());
			ps.setInt(16, inv.getCUSTOMER_NUMBER());
			ps.setDouble(17, inv.getAMOUNT_IN_USD());
			ps.setLong(18,inv.getUNIQUE_CUST_ID());
			
		    ps.executeUpdate();
			ps.close();
			disconnect();
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Connection intrupted");
		}
    	 finally {
			if(connection != null) {
				disconnect();
			}
		}
 		
      }
     
 	 
 	
}
