package com.highradius.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.el.parser.ParseException;
import org.eclipse.jdt.internal.compiler.lookup.ImplicitNullAnnotationVerifier;

import com.highradius.Connection.DatabaseConnection;
import com.highradius.implementation.InvoiceDao;
import com.highradius.implementation.InvoiceDaoImpl;
import com.highradius.model.invoice;
import com.mysql.cj.protocol.x.ReusableOutputStream;

public class AddServlet extends HttpServlet{

	

	
	private InvoiceDao invoiceDao;
	Connection connection = null;
	private DatabaseConnection connection2;
	
	public AddServlet() {
		super();
	}

	public void init() {
		 invoiceDao = new InvoiceDaoImpl();
		 connection = DatabaseConnection.getConnection();
		 
	}
	
	
	//doget
	  protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException{
	 
	        try {
	        	response.setHeader("Access-Control-Allow-Origin", "*");
	            insertRow(request,response);
	        } catch (SQLException | ParseException ex) {
	            throw new ServletException(ex);
	        }
	    }
    
	  // insert row function
	  private void insertRow(HttpServletRequest request, HttpServletResponse response)
	            throws SQLException, IOException, ParseException {
		  
	    	//DATA is fetched using get parameter from request object and set into object
		    int sn = Integer.parseInt(request.getParameter("Sl_no"));
	    	int customerorderid=Integer.parseInt(request.getParameter("customerorderid"));
	    	int cust_number=Integer.parseInt(request.getParameter("SALES_ORG"));
	    	String DISTRIBUTION_CHANNEL=request.getParameter("DISTRIBUTION_CHANNE");
	    	String divisionString = request.getParameter("DIVISION");
	        Double creditValueDouble = Double.parseDouble(request.getParameter("RELEASED_CREDIT_VALUE"));
	        String orderTypeString = request.getParameter("PURCHASE_ORDER_TYPE");
	        int companyCode = Integer.parseInt(request.getParameter("CUSTOMER_CODE"));
	        String orderCreationDateString = request.getParameter("ORDER_CREATION_DATE");
	        String orderCreationTime = request.getParameter("ORDER_CREATION_TIME");
	        String creditArea = request.getParameter("CREDIT_CONTROL_AREA");
	        int SoldParty = Integer.parseInt(request.getParameter("SOLD_TO_PARTY"));
	        Double orderAmount = Double.valueOf(request.getParameter("ORDER_AMOUNT"));
	        String deliveryDate = request.getParameter("REQUESTED_DELIVERY_DATE");
	        String ordercurrent = request.getParameter("ORDER_CURRENCY");
	        String creditStatus = request.getParameter("CREDIT_STATUS");
	        int customerNumber = Integer.parseInt(request.getParameter("CUSTOMER_NUMBER"));
	        Double AmountUSD = Double.valueOf(request.getParameter("AMOUNT_IN_USD"));
	        long uniquecustomer = Long.parseLong(request.getParameter("UNIQUE_CUST_ID"));
	        
	        invoice newRow = new invoice(sn,customerorderid,cust_number, DISTRIBUTION_CHANNEL, divisionString, creditValueDouble, orderTypeString, companyCode, orderCreationDateString, orderCreationTime, creditArea, SoldParty, orderAmount, deliveryDate, ordercurrent, creditStatus, customerNumber, AmountUSD, uniquecustomer);        
	        try {
			   connection2.AddInvoice(newRow);
				
			} catch (Exception e) {
				e.printStackTrace();
			}

	    }

//   Method addInvoice with void return type to Add Invoice data using InvoiceDao insertInvoice method

    public void addInvoice(invoice inv) throws IOException {
        invoiceDao.insertInvoice(inv);
    }
    
    
    // main method
	public static void main(String[] args) throws IOException {
		
		AddServlet addServlet = new AddServlet();
		
	}
}
