package com.highradius.implementation;

import java.util.List;

import com.highradius.Connection.DatabaseConnection;
import com.highradius.model.invoice;


//It is a class  implements InvoiceDao

public class InvoiceDaoImpl implements InvoiceDao{

	DatabaseConnection connection = new DatabaseConnection();
	
	
	//Method getInvoice should call DatabaseConnection getInvoices method

	@Override
	public List<invoice> getInvoice() {

		return connection.getInvoices();
	}

	
	// Method insertInvoice should call DatabaseConnection addInvoice method
	@Override
	public void insertInvoice(invoice inv) {
		connection.AddInvoice();
	}
	
	
	//Rest keep empty methods

	@Override
	public void updateInvoice(int id, invoice inv) {
		
	}

	@Override
	public void deleteInvoice(int id) {
		
		
	}

}
