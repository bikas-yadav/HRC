
import React from 'react';
import GridComponent from './DataGrid';

function App() {
  return (
    <div>
      {/* Other components */}
      <GridComponent />
      {/* Other components */}
    </div>
  );
}

export default App;